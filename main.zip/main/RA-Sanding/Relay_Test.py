import RPi.GPIO as GPIO
import time

from time import sleep

in001= 4 #Pin - 7

GPIO.setmode(GPIO.BCM)
GPIO.setup(in001, GPIO.OUT)

GPIO.output(in001, True)
"""
try:
    while True:
        for x in range(5):
            GPIO.output(in001,True)
            time.sleep(5)
            GPIO.output(in001,False)
            time.sleep(5)

except KeyboardInterrupt:
    GPIO.cleanup()
            
"""
