import math
import evdev
import _thread
import time
import ast
import re
import serial
from time import sleep
from Stepper import stepper

def print_time(threadName, delay, s, steps, dir, speed):
   count = 1
   while count >=1:
      time.sleep(delay)
      count -= 1
      print ("%s: %s" % ( threadName, time.ctime(time.time())))
      testStepper = stepper(s)
      testStepper.step(steps, dir,speed);


################ Read Data ########

with open('/home/pi/Desktop/con_files/angle.txt') as file:
    x= file.read()
    x_mov= re.findall(r'\d+',x)
    x_len= len(x_mov)
    x_int = [int(x) for x in x_mov]
    
    print(x_int)
    print(x_len)

#################
#[stepPin, directionPin, enablePin]
s1=[6,13,4]    #31,33,7--Rpi pins
s2=[17,27,22]  #11,13,15
s3=[20,21,11]   #38,40,23
######### Link Lenghts in cm.
l1=42
l2=35.6
############
ppr=1600  # Pulse Per Revolution
############


a1= 0 #base
a2= -x_int[0]#link 1
a3= x_int[1]#link 2

##print(str(theta1)+" theta2:"+str(theta2)+ " theta3:"+str(theta3))
print(" a1: "+str(a1)+" a2: "+str(a2)+ " a3: "+str(a3))

## Gear Ratios
g1=12.22222222222
g2=10
g3=10
 
# Calculation for step and Speed
step1=(ppr/360)*a1*g1  
#speed1=0.01

step2=(ppr/360)*a2*g2
#speed2=0.01

step3=(ppr/360)*a3*g3  
#speed3=0.01

# Calculation of timedelay for differnt motors
execTime=10

##td1=abs((execTime-(step1*0.002))/step1)
##td2=abs((execTime-(step2*0.002))/step2)
##td3=abs((execTime-(step3*0.002))/step3)

if (step1 == 0):
    td1 = 0
else :
##    td1=abs((execTime-(step1*0.002))/step1)
    td1 = execTime/step1

if (step2 == 0):
    td2 = 0
else:
##    td2=abs((execTime-(step2*0.002))/step2)
    td2 = execTime/step2

if (step3 == 0) :
    td3 = 0
else:
##    td3=abs((execTime-(step3*0.002))/step3)
    td3 = execTime/step3

print(td1)
print(td2)
print(td3)

if step1<0:
    dir1="r"
else:
    dir1="l"
    
if step2<0:
    dir2="l"
else:
    dir2="r"

if step3<0:
    dir3="l"
else:
    dir3="r"


_thread.start_new_thread( print_time, ("stepper-1", 0.2, s1,abs(step1),dir1,td1))
_thread.start_new_thread( print_time, ("stepper-2", 0.2, s2,abs(step2),dir2,td2))
_thread.start_new_thread( print_time, ("stepper-3", 0.2, s3,abs(step3),dir3,td3))

time.sleep(10)

