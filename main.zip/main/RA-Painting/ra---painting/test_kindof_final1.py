import math
import _thread
import time
import RPi.GPIO as GPIO #this library is entirely for valve functioning
from time import sleep
from Stepper import stepper # For movement of arm from one point to another point, this STepper program contains code to run movement in steps
import ast #This library is used to import file as lists
import pyinotify #This library is used for watch manager to watch a certain location

hx = 18.3
hy = 0
hz = 23
global hoi
#[stepPin, directionPin, enablePin]
s1=[6,13,4]    #31,33,7--Rpi pins
s3=[17,27,22]  #11,13,15
s2=[20,21,11]   #38,40,23
    ######### Link Lenghts in cm.
l1=0 ##34.5
l2=42
l3=34.2

NFS = 2
delay = 2.5

hd = 18.3 #Homing coordinate
vd = 23 #Homing coordinate
horiz_dist = 0
vertc_dist = 0

sideMov00 = 0
sideMov01 = 0

DIR = 13   # Direction GPIO Pin
STEP = 6  # Step GPIO Pin

DIR01 = 27   # Direction GPIO Pin
STEP01 = 17  # Step GPIO Pin

DIR02 = 21   # Direction GPIO Pin
STEP02= 20  # Step GPIO Pin
global pv # variable for closing of valve when arm moving to initial position

CW = 1     # Clockwise Rotation
CCW = 0    # Counterclockwise Rotation
SPR = 1600   # Steps per Revolution (360 / 7.5)

GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT) # Assigning the valve a certain pin
GPIO.setup(5, GPIO.OUT) # Assigning the valve a certain pin

################## MAIN CODE #########################################################################################################
def MainCode():
    time.sleep(1)
    with open("/home/pi/Downloads/pai/y_output.txt") as file:
        y_out=ast.literal_eval(file.read()) # importing y coordinates from its file into a list
    print(y_out)    
    with open("/home/pi/Downloads/pai/z_output.txt") as file:
        z_out=ast.literal_eval(file.read()) #  importing z coordinate from its file into a list
    print(z_out)
    
    with open("/home/pi/Downloads/pai/iteration.txt") as file:
        li=ast.literal_eval(file.read()) # importing iteration, time , and other things to a list 
    ################### Input Data ##################
    size = len(y_out)
    print(size)
    ##################### Variables ##################
    sign = 0
    
    NFS = int(li[1]) - 0.5
    delay =  int(li[1]) 
    
    hd = 18.3
    vd = 23
    horiz_dist = 40
    vertc_dist = y_out[0]

    sideMov00 = 0
    sideMov01 = z_out[0]
    pv=0 # pv=0 because we don't want valve to open up when going to first coordinate from its initial homing position
    moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist, pv) # This function makes threads which in turn calls a Stepper function which helps to move arm
    time.sleep(delay)
    #Ater these two commands above the arm is finally on its intitial position
    print(y_out[0])
    print(z_out[0])
    j=0
    for i in range((size-1)): # this loop is now to traverse the remaining number of coordinates
        pv=1 # Now pv=1, because now from all points onwards i.e 2nd point and so on, we want the valve to open up and spray
        GPIO.output(4,GPIO.HIGH) # Opening valve, GPIO.HIGH means the valve is open
        GPIO.output(5,GPIO.HIGH) # Opening valve
        hd = 40
        vd = y_out[i]
        horiz_dist = 40
        vertc_dist = y_out[i+1]
        
##        for z in range
        hoi=z_out[i+1]
        sideMov00 = z_out[i]
        sideMov01 = z_out[i+1]
        moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist, pv)
        time.sleep(delay)
        print("MAIN CODE")
        with open("/home/pi/Downloads/pai/home.txt") as file: #If in case during the moving of bot, we want the bot to move to its homing position and stop
                    ho=ast.literal_eval(file.read())
        if str(ho)=='1': # When the text in Home.txt is == 1, then the homing function will be called and the program will stop
            if z_out[i+1] < 0 : # This is regarding the sensor adjustments so finally the bot is at final homing position without any error
                sign = 1
            else:
                sign = 0
            GPIO.output(4,GPIO.LOW) # Closing the valve, GPIO.LOW means the valve is closed
            GPIO.output(5,GPIO.LOW) # Closing the valve
            Homecoming(sign) # Homing Function is called inside which a variable sign is passed which helps the bot to decide in which direction to turn
            time.sleep(0.5)
            GPIO.output(4,GPIO.LOW)
            GPIO.output(5,GPIO.LOW)
            Homecoming(sign) # Calling Homing function again as to ensure that the bot is at final homing position, so there is no scope for errors after calling homing function twice
            time.sleep(2)
            print('Ho')
            j=1 # Home button is pressed, so that the homing function doesn't get called up again
            open("home.txt","w").close() # This whole line is used to delete the content inside of file
            fil=open("home.txt","w") # function to open the home.txt file, whereas iterator of the file is in fil variable
            fil.write(str(0)) # Writing 0 to Home.txt file as we want that the next time the flow doesn't get disturbed
            fil.close() # Closing the file so that iterator doesn't take random writes
            print('fd')
            fil1=open("some.txt","w") # THis file some.txt is in relation with the number of iteration which was initially passed from GUI
            fil1.write(str(1))
            fil1.close()
            print('qwery')
            break
            
        print('.................................................................................................')
        print(y_out[i+1])
        print(z_out[i+1])
    
    # End of FOR LOOP
    pv=0
    if j==0: # Home Button is not yet pressed
        if z_out[size-1] < 0 : # Checking the last coordinate is positive or negative so as to decide in which direction to turn so as to satisfy homing position
            sign = 1
        else:
            sign = 0    
        GPIO.output(4,GPIO.LOW) # Closing valve
        GPIO.output(5,GPIO.LOW) # Closing valve
        print(sign)
        Homecoming(sign)
        time.sleep(0.5)
        GPIO.output(4,GPIO.LOW) # Closing valve
        GPIO.output(5,GPIO.LOW) # Closing valve
        Homecoming(sign)
        time.sleep(2)
        
        print('Yo')
########################################################################################################################
    
########################################################################################################################################
# The function below helps in threading by calling different commands on each Stepper motor,
# It calls a function inside Stepper.py which makes the movement into some steps and traverse them accordingly
def print_time(threadName, delay, s, steps, dir, speed, pv): 
    print("print_time")
    count = 1
    while count >=1:
        time.sleep(delay)
        count -= 1
        print ("%s: %s" % ( threadName, time.ctime(time.time())))
        testStepper = stepper(s)
        testStepper.step(steps, dir,speed,pv);
        GPIO.output(4,GPIO.HIGH)
        GPIO.output(5,GPIO.HIGH)
      

##########################################################################################################################################################################################

#The function below helps in calling the thread by initializing them which in turn calls print_time function, which gives the final work to threads
def moveSand(ox, oy, oz, x, y, z, pv): 
    htheta1=math.degrees(math.atan(hy/hx))
    oldtheta1=math.degrees(math.atan(oy/ox))
    theta1=math.degrees(math.atan(y/x))
    
    htheta3=-math.degrees(math.acos((hx*hx+hy*hy+hz*hz-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(hz-l1))/(2*l2*l3)))
    oldtheta3=-math.degrees(math.acos((ox*ox+oy*oy+oz*oz-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(oz-l1))/ (2*l2*l3)))
    theta3=-math.degrees(math.acos((x*x+y*y+z*z-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(z-l1))/ (2*l2*l3)))
    
    htheta2=math.degrees(math.atan((hz-l1)*(math.cos(htheta1*math.pi/180)-math.sin(htheta1*math.pi/180))/(hx-hy))) - math.degrees(math.atan((l3*math.sin(htheta3*math.pi/180))/(l2 + l3*math.cos(htheta3*math.pi/180))))
    oldtheta2=math.degrees(math.atan((oz-l1)*(math.cos(oldtheta1*math.pi/180)-math.sin(oldtheta1*math.pi/180))/(ox-oy))) - math.degrees(math.atan((l3*math.sin(oldtheta3*math.pi/180))/(l2 + l3*math.cos(oldtheta3*math.pi/180))))
    theta2=math.degrees(math.atan((z-l1)*(math.cos(theta1*math.pi/180)-math.sin(theta1*math.pi/180))/(x-y))) - math.degrees(math.atan((l3*math.sin(theta3*math.pi/180))/(l2 + l3*math.cos(theta3*math.pi/180))))
    
    print("\n")
    print(str(htheta1)+" htheta2:"+str(htheta2)+ " htheta3:"+str(htheta3))
    print("\n")   
    print("\n")
    print(str(oldtheta1)+" oldtheta2:"+str(oldtheta2)+ " oldtheta3:"+str(oldtheta3))
    print("\n")
    
    ppr=1600  # Pulse Per Revolution
    
    print("\n")
    print(str(x)+" y:"+str(y)+ " y:"+str(z))  
    
    oa1=oldtheta1 - htheta1 #base
    oa2=oldtheta2 - htheta2 #link 1
    oa3=oldtheta3 - htheta3 #link 2
    
    na1=theta1 - htheta1 #base
    na2=theta2 - htheta2 #link 1
    na3=theta3 - htheta3 #link 2
    
    a1 = na1 - oa1
    a2 = na2 - oa2
    a3 = na3 - oa3
    
    print("\n")
    print(str(theta1)+" theta2:"+str(theta2)+ " theta3:"+str(theta3))
    print("\n")
    print(str(a1)+" a2:"+str(a2)+ " a3:"+str(a3))
    print("\n")
    
    ## Gear Ratios
    g1=12.22222222222
    g2=10
    g3=10
     
    step1=(ppr/360)*a1*g1  
    
    step2=(ppr/360)*a2*g2
    
    step3=(ppr/360)*a3*g3  
    
    print(step1)
    print(step2)
    print(step3)
    
    execTime= NFS
    
    if (step1 == 0):
        td1 = 0
    else :
        td1 = execTime/step1
    
    if (step2 == 0):
        td2 = 0
    else:
        td2 = execTime/step2
    
    if (step3 == 0) :
        td3 = 0
    else:
        td3 = execTime/step3
    
    print(td1)
    print(td2)
    print(td3)

    if step1<0:
        dir1="r"
    else:
        dir1="l"

    if step2<0:
        dir2="r"
    else:
        dir2="l"
    
    if step3<0:
        dir3="r"
    else:
        dir3="l"
	#################################################################################################################	
    ui=0 # This varibale acts as a boolean whether user has pressed Home BUtton after pressing the PAUSE button
    with open("/home/pi/Downloads/pai/pause.txt") as file:
        pa=ast.literal_eval(file.read()) #This whole things helps in working of pause and resume control of GUI
    while str(pa)=='0': # if pa=0, i.e pause button is pressed, so program will keep iterating inside of while loop, thereby practically being stopped until and unless resume button is pressed in the GUI which will make pa=1
        print("while pause")
        GPIO.output(4,GPIO.LOW)# When the Bot is paused then the valve should be closed therefore Closing the valve
        GPIO.output(5,GPIO.LOW) # Closing the valve
        with open("/home/pi/Downloads/pai/pause.txt") as file:
            pa=ast.literal_eval(file.read()) # Checking each time in the while loop, waiting for the pa to become 1 i.e. for user to press resume
        with open("/home/pi/Downloads/pai/home.txt") as file:
                    ho=ast.literal_eval(file.read()) # If in case when user presses HOME button after pressing the pause button, then the bot should move to its homing position and therey stopping the bot
        if str(ho)=='1':
            if y < 0 :
                sign = 1
            else:
                sign = 0
            Homecoming(sign)
            time.sleep(0.5)
            Homecoming(sign)
            time.sleep(2)
            print('Ho')
            pa='1'
            ui=1 # If this boolean is set to 1, then the bot will come to complete halt after its homing is done
        if str(pa)=='1': # When user presses Resume button
            GPIO.output(4,GPIO.HIGH)# ON Resuming the bot, the valve should also automativcally start, therefore opening the valve
            GPIO.output(5,GPIO.HIGH) # Opening the valve
            print("resume")
            break
    ######################################################################################################################        
            
    if ui == 0: # Home Button is not pressed after pressing the Pause button
        print("MOVESAND")
        _thread.start_new_thread( print_time, ("stepper-1", 0.2, s1,abs(step1),dir1,td1,pv))# Creation of thread
        _thread.start_new_thread( print_time, ("stepper-2", 0.2, s2,abs(step2),dir2,td2,pv))# Creation of thread
        _thread.start_new_thread( print_time, ("stepper-3", 0.2, s3,abs(step3),dir3,td3,pv))# Creation of Thread
        print("movesand fin")
    #time.sleep(10)
    


############################# Homing Code ###################

def Homecoming(direct):   
	GPIO.setmode(GPIO.BCM)
	GPIO.setwarnings(False)
	GPIO.setup(DIR, GPIO.OUT)
	GPIO.setup(STEP, GPIO.OUT)
	
	GPIO.setup(DIR01, GPIO.OUT)
	GPIO.setup(STEP01, GPIO.OUT)
	
	GPIO.setup(DIR02, GPIO.OUT)
	GPIO.setup(STEP02, GPIO.OUT)
	
	GPIO.output(4,GPIO.LOW)
	GPIO.output(5,GPIO.LOW)
	
	print('*************************************************************************************************')
	print(direct)
	
	if direct == 0 : # This relates to sign variable which was being passed to this function everytime for checking in which direction the bot should turn for coming to its homing position
		GPIO.output(DIR, CCW)
		print(" Counter Clockwise")
	elif direct == 1:
		GPIO.output(DIR, CW)
		print(" Clockwise")
	
	GPIO.output(DIR01, CCW)
	GPIO.output(DIR02, CW)
	
	GPIO.setup(25, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
	GPIO.setup(8, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
	GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
	delay = 0.0008
	time.sleep(1)
	while(GPIO.input(25) != 0 or GPIO.input(8) != 0 or GPIO.input(7) !=0):
        if GPIO.input(25)!=0:
            GPIO.output(STEP, GPIO.HIGH)
            sleep(delay)
            GPIO.output(STEP, GPIO.LOW)
            sleep(delay)
        if GPIO.input(8)!=0:
            GPIO.output(STEP02, GPIO.HIGH)
            sleep(delay)
            GPIO.output(STEP02, GPIO.LOW)
            sleep(delay)
        if GPIO.input(7)!=0:
            GPIO.output(STEP01, GPIO.HIGH)
            sleep(delay)
            GPIO.output(STEP01, GPIO.LOW)
            sleep(delay)
    print (GPIO.input(25))
    print (GPIO.input(8))
    print (GPIO.input(7))


