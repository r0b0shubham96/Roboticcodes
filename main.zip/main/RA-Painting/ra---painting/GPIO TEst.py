import math
#import evdev
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep

from Stepper import stepper


GPIO.setmode(GPIO.BCM)

GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
while(1):
    print (GPIO.input(7))