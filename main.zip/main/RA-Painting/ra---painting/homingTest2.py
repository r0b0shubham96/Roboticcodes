import math
#import evdev
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep

from Stepper import stepper

######
DIR = 13   # Direction GPIO Pin
STEP = 6  # Step GPIO Pin

DIR01 = 27   # Direction GPIO Pin
STEP01 = 17  # Step GPIO Pin

DIR02 = 21   # Direction GPIO Pin
STEP02= 20  # Step GPIO Pin

CW = 1     # Clockwise Rotation
CCW = 0    # Counterclockwise Rotation
SPR = 1600   # Steps per Revolution (360 / 7.5)

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)

GPIO.setup(DIR01, GPIO.OUT)
GPIO.setup(STEP01, GPIO.OUT)

GPIO.setup(DIR02, GPIO.OUT)
GPIO.setup(STEP02, GPIO.OUT)


GPIO.output(DIR, CCW)
GPIO.output(DIR01, CCW)
GPIO.output(DIR02, CW)

GPIO.setup(25, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(8, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
##x = GPIO.input(14)
##print (x)

delay = 0.005

x = GPIO.input(25)
y = GPIO.input(8)
z = GPIO.input(7)

while(x == 1 or y == 1 or z == 1):
    
    x = GPIO.input(25)
    y = GPIO.input(8)
    z = GPIO.input(7)

    while(x != 0):
        #print (GPIO.input(14))
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)

    print (x)
    
    x = GPIO.input(25)
    y = GPIO.input(8)
    z = GPIO.input(7)

    while(y != 0):
        #print (GPIO.input(15))
        GPIO.output(STEP02, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP02, GPIO.LOW)
        sleep(delay)

    print (y)
    
    x = GPIO.input(25)
    y = GPIO.input(8)
    z = GPIO.input(7)

    while(z != 0):
        #print (GPIO.input(18))
        GPIO.output(STEP01, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP01, GPIO.LOW)
        sleep(delay)

    print (z)
    
    x = GPIO.input(25)
    y = GPIO.input(8)
    z = GPIO.input(7)

print('exit')
