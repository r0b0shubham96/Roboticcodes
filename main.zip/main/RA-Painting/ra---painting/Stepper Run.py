

import math
#import evdev
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep

from Stepper import stepper

######
DIR = 21   # Direction GPIO Pin
STEP = 20  # Step GPIO Pin
CW = 1     # Clockwise Rotation
CCW = 0    # Counterclockwise Rotation
SPR = 1600   # Steps per Revolution (360 / 7.5)

GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, CW)

GPIO.setup(15, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

step_count = 300
delay = 0.005

while(GPIO.input(15) != 0):
    print (GPIO.input(15))
    GPIO.output(STEP, GPIO.HIGH)
    sleep(delay)
    GPIO.output(STEP, GPIO.LOW)
    sleep(delay)
