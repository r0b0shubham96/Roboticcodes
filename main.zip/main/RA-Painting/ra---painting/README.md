# RA - Painting

Painting Bot Codes for Kinematics.