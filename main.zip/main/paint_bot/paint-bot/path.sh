#!/bin/bash

scp iteration.txt home.txt pause.txt decide.txt y_output.txt z_output.txt pi@169.254.56.150:/home/pi//Downloads/pai/
