#!/bin/bash

scp dec.txt iteration.txt x_output.txt y_output.txt pi@169.254.56.152:/Desktop/con_files/

