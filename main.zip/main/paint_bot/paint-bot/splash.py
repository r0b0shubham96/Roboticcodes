#import tkinter as tk
from tkinter import *
import time
from tkinter import ttk
from tkinter import messagebox
#import capture_image
#export DISPLAY=:0.0
#import tkFont
#from PIL import Image
import subprocess
import math




class Splash(Toplevel):
	def __init__(self, parent):
		Toplevel.__init__(self, parent)
		self.title("Orangewood Labs")
		self.configure(background='black')
		#self.attributes('-zoomed',True)
		self.overrideredirect(1)
		w = self.winfo_reqwidth()
		h = self.winfo_reqheight()
		ws = self.winfo_screenwidth()
		hs = self.winfo_screenheight()
		x = (ws/2) - (w/2)
		y = (hs/2) - (h/2)
		#self.geometry('+%d+%d' % (x, y))
		gif1=PhotoImage(file="orange.png")
		panel = Label(self,image = gif1)
		panel.grid(row=5,column=5,padx=(300,500),pady=(120,200))
        ## required to make window show before the program gets to the mainloop
		self.update()

class App(Tk):
	def __init__(self):
                
		Tk.__init__(self)
		self.withdraw()
		splash = Splash(self)
        ## setup stuff goes here
        ## simulate a delay while loading
		#capture_image.capture_image()
		time.sleep(2)

        ## finished loading so destroy splash
		splash.destroy()
		
        ## show window again
		self.deiconify()

	
	
	
def callmain(var):
	#root1.destroy()
        print("hjk")
        print(var.get())
        #For the option between Paint Bot and Sand Bot GUI
        if var.get() == 1:
                root1.destroy()
                import main
        elif var.get() == 2:
                root1.destroy()
                import ra_controller

	#import main
	
if __name__ == "__main__":
                  
                  root1=App()
                  root1.title("Setup")
                  #root1.attributes('-zoomed',True)
                  var=IntVar()
                  lab2=Label(root1,text="Which Bot do you want to use --")
                  R1 = Radiobutton(root1, text="Paint Bot", variable=var, value=1)
                  R2 = Radiobutton(root1, text="Sand Bot", variable=var, value=2)
                  lab1=Label(root1,text="Enter Camera distance from workpiece :")
                  ent1=Entry(root1)
                  but1=Button(root1,text="Save",command=lambda:callmain(var))
                  fra1=Frame(root1)
                  gif1=PhotoImage(file="block.png")
                  panel=Label(fra1,image = gif1)
                  lab2.pack()
                  R1.pack()
                  R2.pack()
                  lab1.pack()
                  ent1.pack()
                  but1.pack()
                  fra1.pack(fill=BOTH)
                  panel.pack(pady=(10,0))
                  root1.mainloop()
