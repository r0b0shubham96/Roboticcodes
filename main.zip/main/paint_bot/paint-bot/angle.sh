!/bin/bash

scp dec.txt angle.txt pi@169.254.56.152:Desktop/con_files/
