from tkinter import *
import time
from tkinter import ttk
from tkinter import messagebox
import subprocess
import math
import os
import ast
def checkered(canvas, line_distance):
    # vertical lines at an interval of "line_distance" pixel
    for x in range(line_distance, canvas_width, line_distance):
        canvas.create_line(x,0, x, canvas_height, fill="#476042")
    # horizontal lines at an interval of "line_distance" pixel
    for y in range(line_distance, canvas_height, line_distance):
        canvas.create_line(0, y, canvas_width, y, fill="#476042")

def decide(value):
    #For choosing between which mode should paint bot run in - LINE follower or AREA interpreter
    print("Decide")
    o.clear()
    o.append(value)
    filedec=open("decide.txt","w")
    if value=="Area":
        filedec.write(str(0)) # if the user decides area then 0 will be written in the decide.txt file
    if value=="LINE":
        filedec.write(str(1)) # if the user decides line then 1 will be written in decide.txt file
    filedec.close()

def resetfn():
    print("-------------------------------After Reset--------------------------------------")
    w.delete("ci")
    w.delete("ci2")
    w.delete("line") # deleting all the circles as well as line from the canvas
    itr_val.config(state=NORMAL)
    itr_val.delete(0,10)
    itr_val.insert(0,'1') # Setting the default in the iteration box
    itr_val.config(state=DISABLED)
    time_val.config(state=NORMAL)
    time_val.delete(0,10) # Setting the default in the time box
    time_val.insert(0,'10')
    time_val.config(state=DISABLED)
    selected_points.clear() # Clearing the list which is to be sent to another pi
    real_points.clear() # real coordinates which are mapped ion the canvas are cleared
    line_coordinate.clear()
    open("y_output.txt", "w").close()# Clearing the files created of it's existing data
    open("z_output.txt", "w").close()
    open("iteration.txt", "w").close()
    


# <!===================================================================================>

selected_points=[]
def itera(): # On clicking the Start button , this function will be called
    print("Path")
    #Opening all the necessary files
    fil=open("home.txt","w")
    file2 = open("iteration.txt", "w")
    file3 = open("y_output.txt", "w")
    file4 = open("z_output.txt", "w")
    file6 = open("pause.txt", "w")
    file6.write(str(1))
    file6.close()
    fil.write(str(0))
    final_list = []
    final_list_x = []
    final_list_y = []
    print(selected_points)
    print('selected_points')
    # For ensuring that no coordinates get repeated
    for num in selected_points:
        #print(num)
        if num not in final_list:
            final_list.append(num)
            final_list_x.append(num[0])
            final_list_y.append(num[1])
            '''
   for i in range(len(final_list_y)):
        final_list_y[i]=final_list_y[i]+110
    for i in range(len(final_list_x)):
        if final_list_x[i]>0:
            final_list_x[i]=final_list_x[i]+60
        elif final_list_x[i]<0:
            final_list_x[i]=final_list_x[i]-60
        else:
            final_list_x[i]=final_list_x[i]+0
            '''
    print(final_list)
    # For making the path in between the coordinates so that the user can see specifically how the bot arm will be moving
    for i in range(len(line_coordinate)-1):
        #print("hola")
        xa=line_coordinate[i][0]
        ya=line_coordinate[i][1]
        xb=line_coordinate[i+1][0]
        yb=line_coordinate[i+1][1]
        w.create_line(xa,ya,xb,yb,fill="blue",width=4,arrow=LAST,tags="line",activefill="green")
    # Below 4 lines are used for computation of Area painting
    za=min(final_list_x)
    zb=max(final_list_x)
    xa=min(final_list_y)
    xb=max(final_list_y)
    # Writing into the iteartion.txt file
    file2.write(str(itr_val.get()))
    file2.write(',')
    file2.write(str(int(time_val.get())))#/(len(final_list_y))))
    file2.write(',')
    file2.write(str(40-((xa/20)*2.5)))
    file2.write(',')
    file2.write(str(40-((xb/20)*2.5)))
    file2.write(',')
    file2.write(str((za/20)*0.75))
    file2.write(',')
    file2.write(str((zb/20)*0.75))

    # Conversion of GUI Coordinates into real time coordinates
    for i in range(len(final_list_y)):
        final_list_y[i]=40-((final_list_y[i]/20)*2.5)
    for i in range(len(final_list_x)):
        final_list_x[i]=(final_list_x[i]/20)*0.75
    print(final_list_x)
    print(final_list_y)
        
    file3.write(str(final_list_y))
    file4.write(str(final_list_x))

    #Closing all the files which were opened so that maybe later on iterator doesn't create a problem
    file2.close()
    fil.close()
    file3.close()
    file4.close()
    subprocess.call(['./path.sh']) # Calling the script which will help us move all the files from this pi to another pi
    messagebox.showinfo("Message", "Iteration & Path Files Sent!")
	
		

# <!===================================================================================>


#----------Stop function will close the valve-------------
def stopfn():
    file6 = open("valve.txt", "w")
    file6.write(str(0))
    file6.close()
    messagebox.showinfo("Message", "Stop function called!")	

#--------Pause will stop the paintbot at the same position and close the valve------	
def pausefn():
    file6 = open("pause.txt", "w")
    file6.write(str(0))
    file6.close()
    subprocess.call(['./pause.sh'])

#----Resume will open the valve and then continue the path----------	
def resumefn():
    file6 = open("pause.txt", "w")
    file6.write(str(1))
    file6.close()
    subprocess.call(['./pause.sh'])

#-----Restart will close the valve , goto initial path and then open valve and start all over----	
def restartfn():
    itera()
#home function is called when the home button is pressed, it does homing of the paintbot
def homefn():
    file7 = open("home.txt", "w")
    file7.write(str(1))
    file7.close()
    subprocess.call(['./home.sh'])
    messagebox.showinfo("Message", "Homing!")


###########################################################


#For Checking if the filename which is being saved is not already existing in our profile directory
#This function will prompt user that file name already exists and to select the new one
def check(s,r1):
    print('check')
    path='profiles'
    profil=[]
    files = os.listdir(path)
    for name in files:
        profil.append(name) # Listing all our profiles from its folder into profil list
    for i in range(len(profil)):
        if ('Profile-%s'%s) == (profil[i].replace(' ', '')[:-4]):
            print('check')
            messagebox.showinfo("Message", "File Already exists")
            r1.destroy()
            savefn()
            
    
#Whenever the user will click on Save Button this function will be called
def savefn():
    print('##################################################')
    print(str(selected_points))
    print(str(real_points))
    fil=open("profiles/profile.txt","w")

    #Saving the profile information into a file
    fil.write(str(selected_points))
    fil.write(',')
    fil.write(str(real_points))
    fil.write(',')
    fil.write(str(itr_val.get()))
    fil.write(',')
    fil.write(str(time_val.get()))
    fil.write(',')
    print('decide area or line')
    print(o)
    if o[0]=="Area":
        fil.write(str(0))
    if o[0]=="LINE":
        fil.write(str(1))
    fil.close()
    r1=Tk()
    w = r1.winfo_reqwidth()
    h = r1.winfo_reqheight()
    ws = r1.winfo_screenwidth()
    hs = r1.winfo_screenheight()
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)
    r1.geometry('+%d+%d' % (x, y))
    r1.title("Profile")
    l1=Label(r1,text="Enter the name of your profile:")
    var=StringVar(r1)
    e1=Spinbox(r1, from_=1, to=100,textvariable=var)
    b1=Button(r1,text="Save",command=lambda:[(print(e1.get())),check(e1.get(),r1),(fil.close()),(os.rename('profiles/profile.txt','profiles/Profile-%s.txt'%e1.get())),(r1.destroy())])
    b2=Button(r1,text="Exit",command=lambda:r1.destroy())
    l1.grid(row=0,column=0)
    e1.grid(row=1,column=0)
    b1.grid(row=2,column=1)
    b2.grid(row=2,column=2)
    r1.mainloop()
    

#This function is being invoked from openfn()
#This function loads all the information from profile file into GUI
def openpro(idx,r2):
    #print(idx) # Print the index value
    path='profiles'
    profil=[]
    files = os.listdir(path)
    for name in files:
        profil.append(name)
    print(profil[idx])
    with open("profiles/%s"%profil[idx])as file:
        prolist=ast.literal_eval(file.read())
    print("Prolist")
    resetfn()# Resetting teh canvas as well as all the values from the GUI

    #Loading from the profile file into the GUI
    itr_val.config(state=NORMAL)
    itr_val.delete(0,last=10)
    itr_val.insert(0,prolist[2])
    itr_val.config(state=DISABLED)
    time_val.config(state=NORMAL)
    time_val.delete(0,last=10)
    time_val.insert(0,prolist[3])
    time_val.config(state=DISABLED)
    for u in range(len(prolist[0])):
        (x1,y1)=prolist[0][u]
        selected_points.append((x1,y1)) # Inserting the selected points to the list which is to be sent to the other pi
    real_points=prolist[1]
    for i in range(len(real_points)):
        circle(w, real_points[i][0], canvas_height-real_points[i][1], 6, 12) # Marking coordinates on the GUI again
    filedec=open("decide.txt","w")
    filedec.write(str(prolist[4]))
    filedec.close()
    root.title(" Profile Name - %s"%profil[idx].replace(' ', '')[:-4]) # Changing the name of the main GUI so that user can know which Profile is being used
    r2.destroy()
    
# For deletion of profile which user see fit to delete        
def deletepro(idx,r2):
    path='profiles'
    profil=[]
    files = os.listdir(path)
    for name in files:
        profil.append(name)
    print(profil[idx])
    os.remove("profiles/%s"%profil[idx]) # Removing that file from profile directory
    r2.destroy()
    openfn()

#This function is invoked when Open button is pressed in the GUI
#It loads the profiles in a list from the directory and then make them as buttons so that user can easily access each profile 
def openfn():
    r2=Tk()
    w = r2.winfo_reqwidth()
    h = r2.winfo_reqheight()
    ws = r2.winfo_screenwidth()
    hs = r2.winfo_screenheight()
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)
    r2.geometry('+%d+%d' % (x, y))
    r2.title("Profile")
    path='profiles'
    profil=[]
    files = os.listdir(path)
    for name in files:
        if name == 'profile.txt':
            os.remove("profiles/profile.txt")
        else:
            profil.append(name)
    print(profil)
    siz=len(profil)
    h=1
    for k in range(len(profil)):
        #print(k)
        j= profil[k].replace(' ', '')[:-4]
        b=Button(r2,text=j,command=lambda idx= k:openpro(idx,r2),borderwidth=5).grid(row=h,column=0,sticky=(E,W),padx=(10,10),pady=(10,10))
        d=Button(r2,text='Delete',command=lambda idx= k:deletepro(idx,r2),borderwidth=5).grid(row=h,column=1,sticky=(E,W),padx=(10,10),pady=(10,10))
        #btn_list.append(b)
        h=h+1
    l1=Label(r2,text="Select the profile you want to open:")
    b2=Button(r2,text="Exit",width=15,command=lambda:r2.destroy(),borderwidth=5)
    l1.grid(row=0,column=0)
    b2.grid(row=h,column=0,padx=(10,0),pady=(10,10))
    r2.mainloop()
    





###########################################################


#---------Settings of Iteration----------------------------------
def settfn():
	r=Tk()
	w = r.winfo_reqwidth()
	h = r.winfo_reqheight()
	ws = r.winfo_screenwidth()
	hs = r.winfo_screenheight()
	x = (ws/2) - (w/2)
	y = (hs/2) - (h/2)
	r.geometry('+%d+%d' % (x, y))
	r.title("Settings")
	var=StringVar(r)
	var.set(itr_val.get())
	l1=Label(r,text="Enter the number of iterations:")
	e1=Spinbox(r, from_=1, to=500,textvariable=var)
	var=StringVar(r)
	var.set(time_val.get())
	l2=Label(r,text="Enter the time(in seconds):")
	e2=Spinbox(r, from_=10, to=60,textvariable=var)
	variable1=StringVar(r)
	variable1.set("Select")
	option=OptionMenu(r,variable1,"Area","LINE",command=decide)
	b1=Button(r,text="SET",command=lambda:[(itr_val.config(state=NORMAL)),(itr_val.delete(0,last=10)),
                                               (itr_val.insert(0,e1.get())),(itr_val.config(state=DISABLED)),
                                               (time_val.config(state=NORMAL)),(time_val.delete(0,last=10)),
                                               (time_val.insert(0,e2.get())),(time_val.config(state=DISABLED)),(r.destroy())])
	b2=Button(r,text="EXIT",command=lambda:r.destroy())
	l1.grid(row=0,column=0)
	e1.grid(row=1,column=0)
	l2.grid(row=2,column=0)
	e2.grid(row=3,column=0)
	option.grid(row=4,column=0,pady=(10,0))
	b1.grid(row=5,column=1)
	b2.grid(row=5,column=2)
	r.mainloop()


root =Tk()
root.title("PaintBot")
#root.iconbitmap('paint.ico')	
#root.attributes('-zoomed',True)
content = Frame(root, borderwidth=1,bg='white')
frame = ttk.Frame(content, borderwidth=1,
                  relief="raised", width=200, height=100)
o=[]
variable = StringVar(content)
variable.set("1")
Iteration =Label(content, text="Iteration:",fg='green',font="Times  14 bold ",bg='white')
itr_val = Entry(content,relief="solid",state=DISABLED,width=7,textvariable=variable)
setbut=Button(content,text="Settings",fg='red',font="Times  10 bold ",width=7,command=settfn)
variable = StringVar(content)
variable.set("10")  

Time =Label(content, text="Time:",fg='green',font="Times  14 bold ",bg='white')
time_val = Entry(content,relief="solid",state=DISABLED,width=7,textvariable=variable)

start=PhotoImage(file="icons_paint/play1.png")
start=start.subsample(1)
greenbutton = Button(content, image=start,height=60,width=60,borderwidth=3,command=itera)

pause=PhotoImage(file="icons_paint/pause1.png")
resume=PhotoImage(file="icons_paint/resume1.png")
pause=pause.subsample(1)
resume=resume.subsample(1)


pausebut=Button(content, image=pause,height=60,width=60,borderwidth= 3,command=pausefn)
resbut=Button(content, image=resume,height=60,width=60,borderwidth= 3,command=resumefn)

reset=PhotoImage(file="icons_paint/reset1.png")
restart=PhotoImage(file="icons_paint/restart1.png")
reset=reset.subsample(1)
restart=restart.subsample(1)

home=PhotoImage(file="icons_paint/home1.png")
home=home.subsample(1)
homebut = Button(content, image=home,height=60,width=60,borderwidth= 3,command=homefn)
save=PhotoImage(file="icons_paint/save1.png")
save=save.subsample(1)
savebut = Button(content, image=save,height=60,width=60,borderwidth= 3,command=savefn)
openb=PhotoImage(file="icons_paint/open1.png")
openb=openb.subsample(1)
openbut = Button(content, image=openb,height=60,width=60,borderwidth= 3,command=openfn)  

resetbut = Button(content, image=reset,height=60,width=60,borderwidth= 3,command=resetfn) 
restbut = Button(content, image=restart,height=60,width=60,borderwidth= 3,command=restartfn)


print(frame.winfo_screenwidth())
print(frame.winfo_screenheight())
line_distance = 20


canvas_width = (math.ceil((frame.winfo_screenwidth()) /
                          line_distance))*line_distance
canvas_height = (math.ceil((frame.winfo_screenheight()) /
                           line_distance))*line_distance

w = Canvas(frame,
           width=800,
           height=320,bg='white')
#Grid-----------------------------------------------		   
content.grid(column=0, row=6,columnspan=7, sticky=(N, E, W))
frame.grid(column=0, row=0, columnspan=10, rowspan=5, sticky=(N, E, W))
Iteration.grid(column=0, row=6, sticky=(N, E,W))
itr_val.grid(column=0, row=7,sticky=(N, E,W))
setbut.grid(column=0,row=8,columnspan=2)
Time.grid(column=1, row=6, sticky=(N, E,W))
time_val.grid(column=1, row=7,sticky=(N, E,W))
w.grid(column=0, row=0, columnspan=3, rowspan=4)
greenbutton.grid(column=2, row=6,rowspan=2)
Label(content,text="Start",fg='green',font='bold',bg='white').grid(row=8,column=2)
pausebut.grid(column=3, row=6,rowspan=2)
Label(content,text="Pause",fg='green',font='bold',bg='white').grid(row=8,column=3)
resbut.grid(column=4, row=6,rowspan=2)
Label(content,text="Resume",fg='green',font='bold',bg='white').grid(row=8,column=4)
resetbut.grid(column=5, row=6,rowspan=2)
Label(content,text="Reset",fg='green',font='bold',bg='white').grid(row=8,column=5)
restbut.grid(column=6, row=6,rowspan=2)
Label(content,text="Restart",fg='green',font='bold',bg='white').grid(row=8,column=6)
homebut.grid(column=7, row=6,rowspan=2)
Label(content,text="Home",fg='green',font='bold',bg='white').grid(row=8,column=7)
openbut.grid(column=8, row=6,rowspan=2)
Label(content,text="Open",fg='green',font='bold',bg='white').grid(row=8,column=8)
savebut.grid(column=9, row=6,rowspan=2)
Label(content,text="Save",fg='green',font='bold',bg='white').grid(row=8,column=9)

checkered(w, line_distance)
selected_points = []
line_coordinate=[]
real_points=[]
profil=[]


def distance(p0, p1):
	return math.sqrt((p0[0] - p1[0])**2 + (p0[1] - p1[1])**2)


def circle(canvas, x, y, r1, r2):
	id = canvas.create_oval(x-r1, y-r1, x+r1, y+r1, fill="red", tags="ci")
	id2 = canvas.create_oval(x-r2, y-r2, x+r2, y+r2, tags="ci2")
	line_coordinate.append((x,y))


def click(event):
        x, y = event.x, abs(event.y-canvas_height)
        x_min = (math.floor(x/line_distance))*line_distance
        x_max = (math.ceil(x/line_distance))*line_distance
        y_min = (math.floor(y/line_distance))*line_distance
        y_max = (math.ceil(y/line_distance))*line_distance
        n = [(x_min, y_min), (x_min, y_max), (x_max, y_max), (x_max, y_min)]
        dis = []
        for j in n:
                d = distance((x, y), j)
                dis.append(d)
        print('{}, {}'.format(x, y))

        selected_cordinate = n[dis.index(min(dis))]
        (x1, y1) = selected_cordinate
        y1=(y1-480)*-1
        x1=x1-400
        selected_points.append((x1,y1))
        (x0, y0) = selected_cordinate
        real_points.append((x0,y0))
        print(selected_points)
        circle(w, x0, canvas_height-y0, 6, 12)
            
def key(event):
	print("pressed", repr(event.char))


w.bind("<Key>", key)
w.bind("<Button-1>", click)
wso = root.winfo_screenwidth()
hso = root.winfo_screenheight()
root.geometry("1370x768+0+0")
root.mainloop()
