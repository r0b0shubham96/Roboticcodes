#!/bin/bash

scp pause.txt pi@169.254.56.150:/home/pi//Downloads/pai/
