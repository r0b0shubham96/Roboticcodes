"""
Created on Mon Nov 26 14:12:46 2018
@author: anubhav singh

"""

import cv2

# resize image
def image_resize(image, width = None, height = None, inter = cv2.INTER_AREA):
       dim = None
       (h, w) = image.shape[:2]
       
       if width is None and height is None:
              return image
       
       if width is None:
              r = height / float(h)
              dim = (int(w * r), height)
       else:
              r = width / float(w)
              dim = (width, int(h * r))
              
       resized = cv2.resize(image, dim, interpolation = inter)

       return resized




def get_image(camera):
       img = camera.read()[1]
       del(camera)
       return img

def capture_image():
       
       ramp_frames = 30
       camera_port = 0
       camera = cv2.VideoCapture(camera_port)
       
       for i in range(ramp_frames):
              get_image(camera)

       print("Taking image...")
       camera_capture = get_image(camera)

       file = "block.png"
       original = "original.png"
       contoured_image = "contoured_image.png"

       cv2.imwrite(file, camera_capture)
       

       # read captured image
       img = cv2.imread("block.png")


       # crop image
       file1="backorig57.png"
       resized = img[60:470, 140:560]
       cv2.imwrite(file1,resized)
       resized = image_resize(resized, height  = 320)
       #ratio = img.shape[0]/float(resized.shape[0])
       file = "back.png"
       cv2.imwrite(file, resized)
        
capture_image()