#!/bin/bash

scp angle.txt iteration.txt coordinatesarray.txt pi@169.254.56.152:Desktop/con_files/


