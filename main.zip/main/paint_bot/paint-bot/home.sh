#!/bin/bash

scp home.txt pi@169.254.56.150:/home/pi//Downloads/pai/
