from tkinter import *
import time
from tkinter import ttk
from tkinter import messagebox
import subprocess
import math
def checkered(canvas, line_distance):
    # vertical lines at an interval of "line_distance" pixel
    for x in range(line_distance, canvas_width, line_distance):
        canvas.create_line(x,0, x, canvas_height, fill="#476042")
    # horizontal lines at an interval of "line_distance" pixel
    for y in range(line_distance, canvas_height, line_distance):
        canvas.create_line(0, y, canvas_width, y, fill="#476042")

def decide(value):
    print("Decide")
    filedec=open("decide.txt","w")
    if value=="Area":
        filedec.write(str(0))
    if value=="LINE":
        filedec.write(str(1))
    filedec.close()

def resetfn():
    print("-------------------------------After Reset--------------------------------------")
    w.delete("ci")
    w.delete("ci2")
    w.delete("line")
    itr_val.config(state=NORMAL)
    itr_val.delete(0,10)
    itr_val.insert(0,'1')
    itr_val.config(state=DISABLED)
    time_val.config(state=NORMAL)
    time_val.delete(0,10)
    time_val.insert(0,'10')
    time_val.config(state=DISABLED)
    selected_points.clear()
    line_coordinate.clear()
    #ipl[0]=0
    open("y_output.txt", "w").close()
    open("z_output.txt", "w").close()
    open("iteration.txt", "w").close()
    


# <!===================================================================================>


def itera():
    print("Path")
    fil=open("home.txt","w")
    file2 = open("iteration.txt", "w")
    file3 = open("y_output.txt", "w")
    file4 = open("z_output.txt", "w")
    file6 = open("pause.txt", "w")
    file6.write(str(1))
    file6.close()
	#file2.write(itr_val.get())
    fil.write(str(0))
    final_list = []
    final_list_x = []
    final_list_y = []
    for num in selected_points:
        if num not in final_list:
            final_list.append(num)
            final_list_x.append(num[0])
            final_list_y.append(num[1])
            '''
   for i in range(len(final_list_y)):
        final_list_y[i]=final_list_y[i]+110
    for i in range(len(final_list_x)):
        if final_list_x[i]>0:
            final_list_x[i]=final_list_x[i]+60
        elif final_list_x[i]<0:
            final_list_x[i]=final_list_x[i]-60
        else:
            final_list_x[i]=final_list_x[i]+0
            '''
    print(final_list)
    for i in range(len(line_coordinate)-1):
        print("hola")
        xa=line_coordinate[i][0]
        ya=line_coordinate[i][1]
        xb=line_coordinate[i+1][0]
        yb=line_coordinate[i+1][1]
        w.create_line(xa,ya,xb,yb,fill="blue",width=4,arrow=LAST,tags="line",activefill="green")
    
    za=min(final_list_x)
    zb=max(final_list_x)
    xa=min(final_list_y)
    xb=max(final_list_y)
    file2.write(str(itr_val.get()))
    file2.write(',')
    file2.write(str(int(time_val.get())))#/(len(final_list_y))))
    file2.write(',')
    file2.write(str(40-((xa/20)*2.5)))
    file2.write(',')
    file2.write(str(40-((xb/20)*2.5)))
    file2.write(',')
    file2.write(str((za/20)*0.75))
    file2.write(',')
    file2.write(str((zb/20)*0.75))

    for i in range(len(final_list_y)):
        final_list_y[i]=40-((final_list_y[i]/20)*2.5)
    for i in range(len(final_list_x)):
        final_list_x[i]=(final_list_x[i]/20)*0.75
    print(final_list_x)
    print(final_list_y)
        
    file3.write(str(final_list_y))
    file4.write(str(final_list_x))
    file2.close()
    fil.close()
    file3.close()
    file4.close()
    subprocess.call(['./path.sh'])
    messagebox.showinfo("Message", "Iteration & Path Files Sent!")
	
		

# <!===================================================================================>


#----------Stop function will close the valve-------------
def stopfn():
    file6 = open("valve.txt", "w")
    file6.write(str(0))
    file6.close()
    messagebox.showinfo("Message", "Stop function called!")	

#--------Pause will stop the paintbot at the same position and close the valve------	
def pausefn():
    file6 = open("pause.txt", "w")
    file6.write(str(0))
    file6.close()
    subprocess.call(['./pause.sh'])

#----Resume will open the valve and then continue the path----------	
def resumefn():
    file6 = open("pause.txt", "w")
    file6.write(str(1))
    file6.close()
    subprocess.call(['./pause.sh'])

#-----Restart will close the valve , goto initial path and then open valve and start all over----	
def restartfn():
    itera()
#home function is called when the home button is pressed, it does homing of the paintbot
def homefn():
    file7 = open("home.txt", "w")
    file7.write(str(1))
    file7.close()
    subprocess.call(['./home.sh'])
    messagebox.showinfo("Message", "Homing!")

#---------Settings of Iteration----------------------------------
def settfn():
	r=Tk()
	w = r.winfo_reqwidth()
	h = r.winfo_reqheight()
	ws = r.winfo_screenwidth()
	hs = r.winfo_screenheight()
	x = (ws/2) - (w/2)
	y = (hs/2) - (h/2)
	r.geometry('+%d+%d' % (x, y))
	r.title("Settings")
	var=StringVar(r)
	var.set(itr_val.get())
	l1=Label(r,text="Enter the number of iterations:")
	e1=Spinbox(r, from_=1, to=500,textvariable=var)
	var=StringVar(r)
	var.set(time_val.get())
	l2=Label(r,text="Enter the time(in seconds):")
	e2=Spinbox(r, from_=10, to=60,textvariable=var)
	b1=Button(r,text="SET",command=lambda:[(itr_val.config(state=NORMAL)),(itr_val.delete(0,last=10)),
                                               (itr_val.insert(0,e1.get())),(itr_val.config(state=DISABLED)),
                                               (time_val.config(state=NORMAL)),(time_val.delete(0,last=10)),
                                               (time_val.insert(0,e2.get())),(time_val.config(state=DISABLED)),(r.destroy())])
	b2=Button(r,text="EXIT",command=lambda:r.destroy())
	l1.grid(row=0,column=0)
	e1.grid(row=1,column=0)
	l2.grid(row=2,column=0)
	e2.grid(row=3,column=0)
	b1.grid(row=4,column=1)
	b2.grid(row=4,column=2)
	r.mainloop()


root =Tk()
root.title("PaintBot")
#root.iconbitmap('paint.ico')	
root.attributes('-zoomed',True)
content = Frame(root, borderwidth=1,bg='white')
frame = ttk.Frame(content, borderwidth=1,
                  relief="raised", width=200, height=100)

variable = StringVar(content)
variable.set("1")
Iteration =Label(content, text="Iteration:",fg='green',font="Times  14 bold ",bg='white')
itr_val = Entry(content,relief="solid",state=DISABLED,width=7,textvariable=variable)
setbut=Button(content,text="Settings",fg='red',font="Times  10 bold ",width=7,command=settfn)
variable = StringVar(content)
variable.set("10")  

Time =Label(content, text="Time:",fg='green',font="Times  14 bold ",bg='white')
time_val = Entry(content,relief="solid",state=DISABLED,width=7,textvariable=variable)

start=PhotoImage(file="play1.png")
start=start.subsample(1)
#stop=PhotoImage(file="stop1.png")
#stop=stop.subsample(1)
#redbutton = Button(content,image=stop,height=60,width=5,borderwidth= 3,command=stopfn)
greenbutton = Button(content, image=start,height=60,width=5,borderwidth=3,command=itera)

pause=PhotoImage(file="pause1.png")
resume=PhotoImage(file="resume1.png")
pause=pause.subsample(1)
resume=resume.subsample(1)


pausebut=Button(content, image=pause,height=60,width=5,borderwidth= 3,command=pausefn)
resbut=Button(content, image=resume,height=60,width=1,borderwidth= 3,command=resumefn)

reset=PhotoImage(file="reset1.png")
restart=PhotoImage(file="restart1.png")
reset=reset.subsample(1)
restart=restart.subsample(1)

home=PhotoImage(file="home1.png")
home=home.subsample(1)
homebut = Button(content, image=home,height=60,width=5,borderwidth= 3,command=homefn)  

resetbut = Button(content, image=reset,height=60,width=5,borderwidth= 3,command=resetfn) 
restbut = Button(content, image=restart,height=60,width=5,borderwidth= 3,command=restartfn)

variable1=StringVar(content)
variable1.set("Select")
option=OptionMenu(content,variable1,"Area","LINE",command=decide)

print(frame.winfo_screenwidth())
print(frame.winfo_screenheight())
line_distance = 20


canvas_width = (math.ceil((frame.winfo_screenwidth()) /
                          line_distance))*line_distance
canvas_height = (math.ceil((frame.winfo_screenheight()) /
                           line_distance))*line_distance

w = Canvas(frame,
           width=800,
           height=320,bg='white')

		   
gif1=PhotoImage(file='back.png')
w.create_image(230,0,image=gif1,anchor=NW)		   
		   
#Grid-----------------------------------------------		   
content.grid(column=0, row=6,columnspan=7, sticky=(N, E, W))
frame.grid(column=0, row=0, columnspan=10, rowspan=5, sticky=(N, E, W))
Iteration.grid(column=0, row=6, sticky=(N, E,W))
itr_val.grid(column=0, row=7,sticky=(N, E,W))
setbut.grid(column=0,row=8,columnspan=2)
Time.grid(column=1, row=6, sticky=(N, E,W))
time_val.grid(column=1, row=7,sticky=(N, E,W))
w.grid(column=0, row=0, columnspan=3, rowspan=4)
option.grid(column=2,row=6,rowspan=2,pady=(25,0),padx=(0,0))
greenbutton.grid(column=3, row=6,rowspan=2,sticky=(E,W))#,padx=(10,0))
Label(content,text="Start",fg='green',font='bold',bg='white').grid(row=8,column=3)
#redbutton.grid(column=3, row=6,rowspan=2,sticky=(E,W))
#Label(content,text="Stop",fg='green',font='bold',bg='white').grid(row=8,column=3)
pausebut.grid(column=4, row=6,rowspan=2,sticky=(E,W))
Label(content,text="Pause",fg='green',font='bold',bg='white').grid(row=8,column=4)
resbut.grid(column=5, row=6,rowspan=2,sticky=(E,W))#,padx=(5,5))
Label(content,text="Resume",fg='green',font='bold',bg='white').grid(row=8,column=5)
resetbut.grid(column=6, row=6,rowspan=2,sticky=(E,W))
Label(content,text="Reset",fg='green',font='bold',bg='white').grid(row=8,column=6)
restbut.grid(column=7, row=6,rowspan=2,sticky=(E,W))
Label(content,text="Restart",fg='green',font='bold',bg='white').grid(row=8,column=7)
homebut.grid(column=8, row=6,rowspan=2,sticky=(E,W))
Label(content,text="Home",fg='green',font='bold',bg='white').grid(row=8,column=8)


root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=0)
content.columnconfigure(0, weight=0)
content.columnconfigure(1, weight=0)
content.columnconfigure(2, weight=0)
content.columnconfigure(3, weight=0)
content.columnconfigure(4, weight=0)
content.columnconfigure(5, weight=0)
content.columnconfigure(6, weight=0)
content.columnconfigure(7, weight=0)
content.rowconfigure(1, weight=0)
content.rowconfigure(2, weight=0)
content.rowconfigure(3, weight=0)
content.rowconfigure(4, weight=0)
content.rowconfigure(5, weight=0)
content.rowconfigure(6, weight=0)
content.rowconfigure(7, weight=0)
content.rowconfigure(8, weight=0)
content.rowconfigure(9, weight=0)
content.rowconfigure(10, weight=0)

checkered(w, line_distance)
selected_points = []
line_coordinate=[]


def distance(p0, p1):
	return math.sqrt((p0[0] - p1[0])**2 + (p0[1] - p1[1])**2)


def circle(canvas, x, y, r1, r2):
	id = canvas.create_oval(x-r1, y-r1, x+r1, y+r1, fill="red", tags="ci")
	id2 = canvas.create_oval(x-r2, y-r2, x+r2, y+r2, tags="ci2")
	line_coordinate.append((x,y))


def click(event):
        x, y = event.x, abs(event.y-canvas_height)
        x_min = (math.floor(x/line_distance))*line_distance
        x_max = (math.ceil(x/line_distance))*line_distance
        y_min = (math.floor(y/line_distance))*line_distance
        y_max = (math.ceil(y/line_distance))*line_distance
        n = [(x_min, y_min), (x_min, y_max), (x_max, y_max), (x_max, y_min)]
        dis = []
        for j in n:
                d = distance((x, y), j)
                dis.append(d)
        print('{}, {}'.format(x, y))

        selected_cordinate = n[dis.index(min(dis))]
        (x1, y1) = selected_cordinate
        y1=(y1-480)*-1
        x1=x1-400
        selected_points.append((x1,y1))
        (x0, y0) = selected_cordinate
        print(selected_points)
        circle(w, x0, canvas_height-y0, 6, 12)
            
def key(event):
	print("pressed", repr(event.char))


w.bind("<Key>", key)
w.bind("<Button-1>", click)
wso = root.winfo_screenwidth()
hso = root.winfo_screenheight()
root.geometry("1370x768+0+0")
root.mainloop()

