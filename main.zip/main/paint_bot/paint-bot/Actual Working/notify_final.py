import pyinotify # This library helps in watching a certain file location
import ast # This library hepls in imporing file items in form of a list
import MapAreaPaint # IF the user chooses AREA as an option
import finalWithArtifiHoming1 # IF the user chooses LINE follower as an option

class MyEventHandler(pyinotify.ProcessEvent):

    def process_IN_CLOSE_WRITE(self, event):
        if (event.pathname=='/home/pi/Downloads/pai/decide.txt'): # As soon as the coordinate file comes from GUI , this function will get automatially called with the help of pyinotify
            with open("/home/pi/Downloads/pai/decide.txt") as file: # This file is used to see which option did the user choose between AREA and LINE
                de=ast.literal_eval(file.read())
            if str(de)=='1': # IF the user chose LINE
                print("PATH")
                with open("/home/pi/Downloads/pai/iteration.txt") as file: # Reading the iteration.txt file, so as to see how many times a certain piece of coordinates are to be followed
                    li=ast.literal_eval(file.read())
                print("li[0] = ",li[0])
                if li[0]==1: # If iteration is = 1
                    print("lio=1")
                    with open("/home/pi/Downloads/pai/some.txt") as file:  # Reading this file means that pause button was pressed and Home was called, OR Home Button was pressed and so there is no need to proceed further
                        so=ast.literal_eval(file.read())
                    if str(so)=='1': # if so==1, then just break from this loop and stop the bot
                        print("HOMINGLY")
                        fil3=open("some.txt","w")
                        fil3.write(str(0)) # Writing 0 to some.txt for future use of paint bo
                        fil3.close()
                    else: 
                        finalWithArtifiHoming1.MainCode() # Calling the main function in the main file which will iterates accordingly as given in the GUI
                        fil3=open("some.txt","w")
                        fil3.write(str(0)) # Ensuring that Some.txt has 0 only written inside it
                        fil3.close()
                else: # IF iteration is more than 1
                    print("lio>1")
                    for i in range(int(li[0])):
                    #print("##")
                        print(i)
                        with open("/home/pi/Downloads/pai/some.txt") as file:
                            so=ast.literal_eval(file.read())
                        if str(so)=='1':
                            fil3=open("some.txt","w")
                            fil3.write(str(0))
                            fil3.close()
                            break
                        else:
                            finalWithArtifiHoming1.MainCode()  # Calling the main function in the main file which will iterates accordingly as given in the GUI
            else: # IF the user chose AREA
                print("AREA")
                with open("/home/pi/Downloads/pai/iteration.txt") as file: # Reading the iteration.txt file, so as to see how many times a certain piece of coordinates are to be followed
                    li=ast.literal_eval(file.read())
                print("li[0] = ",li[0])
                if li[0]==1: # If iteration is = 1
                    print("lio=1")
                    with open("/home/pi/Downloads/pai/some.txt") as file: # Reading this file means that pause button was pressed and Home was called, OR Home Button was pressed and so there is no need to proceed further
                        so=ast.literal_eval(file.read())
                    if str(so)=='1': # if so==1, then just break from this loop and stop the bot
                        print("HOMINGLY")
                        fil3=open("some.txt","w")
                        fil3.write(str(0))
                        fil3.close()
                    else:
                        MapAreaPaint.MainCode() # Calling the main function in the main file which will iterates accordingly as given in the GUI
                        fil3=open("some.txt","w")
                        fil3.write(str(0))
                        fil3.close()
                else:
                    print("lio>1")
                    for i in range(int(li[0])):
                    print("##")
                        print(i)
                        with open("/home/pi/Downloads/pai/some.txt") as file:
                            so=ast.literal_eval(file.read())
                        if str(so)=='1':
                            fil3=open("some.txt","w")
                            fil3.write(str(0))
                            fil3.close()
                            break
                        else:
                            MapAreaPaint.MainCode() # Calling the main function in the main file which will iterates accordingly as given in the GUI
                
        print ("CLOSE_WRITE event:", event.pathname)
        
    def process_IN_MODIFY(self, event):
        print ("MODIFY event:", event.pathname)

wm = pyinotify.WatchManager()
wm.add_watch('/home/pi/Downloads/pai', pyinotify.ALL_EVENTS, rec=True)

    # event handler
eh = MyEventHandler()

    # notifier
notifier = pyinotify.Notifier(wm, eh)
notifier.loop()

