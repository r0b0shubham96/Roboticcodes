import re
import ast
with open("/home/pi/Downloads/pai/x_output.txt") as file:
    y_mylist=ast.literal_eval(file.read())
    print(y_mylist)
        
with open("/home/pi/Downloads/pai/y_output.txt") as file:
    z_mylist=ast.literal_eval(file.read())
    print(z_mylist)