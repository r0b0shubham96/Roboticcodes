import math
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep
from Stepper import stepper
import ast
#import notify
import pyinotify

with open("/home/pi/Downloads/pai/y_output.txt") as file:
    y_out=ast.literal_eval(file.read())
print(y_out)    
with open("/home/pi/Downloads/pai/z_output.txt") as file:
    z_out=ast.literal_eval(file.read())
print(z_out)
dist=[]
tot=0
#sum=math.sqrt(((0-y_out[0])**2)+((23-z_out[0])**2)+((40-18.3)**2))
#dist.append(sum)
for i in range(len(y_out)-1):
    print(i)
    
    sum=math.sqrt(((y_out[i+1]-y_out[i])**2)+((z_out[i+1]-z_out[i])**2))
    dist.append(sum)#
    tot=tot+sum
    #tot=tot+sum
print(dist)
print(tot)
tot=10/tot
print(tot)
print(tot*dist[0])
print(tot*dist[1])
print((tot*dist[0])+(tot*dist[1]))