import math
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep
from Stepper import stepper
import ast



with open("/home/pi/Downloads/pai/y_output.txt") as file:
        y_out=ast.literal_eval(file.read())
print(y_out)    
with open("/home/pi/Downloads/pai/z_output.txt") as file:
    z_out=ast.literal_eval(file.read())
print(z_out)
    
with open("/home/pi/Downloads/pai/iteration.txt") as file:
    li=ast.literal_eval(file.read())
    ################### Input Data ##################
size = len(y_out)
print(size)
    ##################### Variables ##################
sign = 0
dist=[]
tot=0
for i in range(len(y_out)-1):
    #print(i)
    sum=math.sqrt((((y_out[i+1]-y_out[i]))**2)+((z_out[i+1]-z_out[i])**2))
    print(sum)
    dist.append(sum)#
    tot=tot+sum
print(dist)
print (tot)
totd=int(li[1])/tot