import math
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep
from Stepper import stepper
import ast
import re

hx = 18.3
hy = 0
hz = 23

#[stepPin, directionPin, enablePin]
s1=[6,13,4]    #31,33,7--Rpi pins
s3=[17,27,22]  #11,13,15
s2=[20,21,11]   #38,40,23
    ######### Link Lenghts in cm.
l1=0 ##34.5
l2=42
l3=34.2

NFS = 1
delay = 1.44

    #Repeat = (ZB-ZA)/ SideRes

    #SideRes = (ZB-ZA)/ Repeat

hd = 18.3
vd = 23
horiz_dist = 0
vertc_dist = 0

sideMov00 = 0
sideMov01 = 0
################## MAIN CODE ##########################
def MainCode():
    with open("/home/pi/Downloads/pai/y_output.txt") as file:
        y_mylist=ast.literal_eval(file.read())
        print(y_mylist)
        
    with open("/home/pi/Downloads/pai/z_output.txt") as file:
        z_mylist=ast.literal_eval(file.read())
        print(z_mylist)
    ################### Input Data ##################
    
    
    y_len = len(y_mylist)
    z_len = len(z_mylist)
    
    #SideRes = int(mylist[0])
    ##################### Variables ##################
    NFS = 1
    delay = 1.44

    #Repeat = (ZB-ZA)/ SideRes

    #SideRes = (ZB-ZA)/ Repeat

    hd = 18.3
    vd = 23
    horiz_dist = 40
    vertc_dist = y_mylist[0]

    sideMov00 = 0
    sideMov01 = z_mylist[0]

    ###################################################
    ######
    DIR = 13   # Direction GPIO Pin
    STEP = 6  # Step GPIO Pin

    DIR01 = 27   # Direction GPIO Pin
    STEP01 = 17  # Step GPIO Pin

    DIR02 = 21   # Direction GPIO Pin
    STEP02= 20  # Step GPIO Pin


    CW = 1     # Clockwise Rotation
    CCW = 0    # Counterclockwise Rotation
    SPR = 1600   # Steps per Revolution (360 / 7.5)

    GPIO.setmode(GPIO.BCM)
    GPIO.setup(DIR, GPIO.OUT)
    GPIO.setup(STEP, GPIO.OUT)

    GPIO.setup(DIR01, GPIO.OUT)
    GPIO.setup(STEP01, GPIO.OUT)

    GPIO.setup(DIR02, GPIO.OUT)
    GPIO.setup(STEP02, GPIO.OUT)


    GPIO.output(DIR, CCW)
    GPIO.output(DIR01, CCW)
    GPIO.output(DIR02, CW)

    GPIO.setup(14, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(15, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

    
    #[stepPin, directionPin, enablePin]
    #s1=[6,13,4]    #31,33,7--Rpi pins
    #s3=[17,27,22]  #11,13,15
    #s2=[20,21,11]   #38,40,23
    ######### Link Lenghts in cm.
    #l1=0 ##34.5
    #l2=42
    #l3=34.2
    ######## Home Position ########
    #hx = 18.3
    #hy = 0
    #hz = 23
    
    NFS = 2
    delay = 2.5
    
    hd = 18.3
    vd = 23
    horiz_dist = 40
    vertc_dist = y_mylist[0]
    sideMov00 = 0
    sideMov01 = z_mylist[0]
    
    moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
    time.sleep(delay)
    
    for i in range(y_len-1):
        hd = 40
        vd = y_mylist[i]
        horiz_dist = 40
        vertc_dist = y_mylist[i+1]
        sideMov00 = z_mylist[i]
        sideMov01 = z_mylist[i+1]
        moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
        moveSand(hd, y_mylist[i], z_mylist[i], horiz_dist, y_mylist[i+1], z_mylist[i+1])
        time.sleep(delay)
        
    
    
    
    '''
    x = 0
    y = 0
    for i in range(int(Repeat)):
        y = x+SideRes
        hd = 40
        vd = YA
        horiz_dist = 40
        vertc_dist = YA
        sideMov00 = x
        sideMov01 = y
        moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
        time.sleep(delay)
        
        hd = 40
        vd = YA
        horiz_dist = 40
        vertc_dist = YB
        sideMov00 = 0
        sideMov01 = 0
        moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
        time.sleep(delay)
        
        hd = 40
        vd = YB
        horiz_dist = 40
        vertc_dist = YA
        sideMov00 = 0
        sideMov01 = 0
        moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
        time.sleep(delay)
        
        x = y
        
    print(y)

    ##Homecoming()
    ##time.sleep(20)


    hd = 40
    vd = YA
    horiz_dist = 18.3
    vertc_dist = 23
    sideMov00 = ZB
    sideMov01 = 0    

    moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
    time.sleep(delay)
    '''
    #open("iteration.txt","w").close()


###################################################
def print_time(threadName, delay, s, steps, dir, speed):
   count = 1
   while count >=1:
      time.sleep(delay)
      count -= 1
      print ("%s: %s" % ( threadName, time.ctime(time.time())))
      testStepper = stepper(s)
      testStepper.step(steps, dir,speed);
      

##########################################################################################################################################################################################


def moveSand(ox, oy, oz, x, y, z): 
    htheta1=math.degrees(math.atan(hy/hx))
    htheta3=-math.degrees(math.acos((hx*hx+hy*hy+hz*hz-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(hz-l1))/(2*l2*l3)))  
    htheta2=math.degrees(math.atan((hz-l1)*(math.cos(htheta1*math.pi/180)-math.sin(htheta1*math.pi/180))/(hx-hy))) - math.degrees(math.atan((l3*math.sin(htheta3*math.pi/180))/(l2 + l3*math.cos(htheta3*math.pi/180))))
    
    print("\n")
    print(str(htheta1)+" htheta2:"+str(htheta2)+ " htheta3:"+str(htheta3))
    print("\n")
    
    oldtheta1=math.degrees(math.atan(oy/ox))
    oldtheta3=-math.degrees(math.acos((ox*ox+oy*oy+oz*oz-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(oz-l1))/ (2*l2*l3)))
    oldtheta2=math.degrees(math.atan((oz-l1)*(math.cos(oldtheta1*math.pi/180)-math.sin(oldtheta1*math.pi/180))/(ox-oy))) - math.degrees(math.atan((l3*math.sin(oldtheta3*math.pi/180))/(l2 + l3*math.cos(oldtheta3*math.pi/180))))
    
    print("\n")
    print(str(oldtheta1)+" oldtheta2:"+str(oldtheta2)+ " oldtheta3:"+str(oldtheta3))
    print("\n")
    
    ppr=1600  # Pulse Per Revolution
    
##    x = 17.8 #17.8
##    y = 15  #18.4
##    z = 18.4
    
    print("\n")
    print(str(x)+" y:"+str(y)+ " y:"+str(z))  
    
    theta1=math.degrees(math.atan(y/x))
    theta3=-math.degrees(math.acos((x*x+y*y+z*z-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(z-l1))/ (2*l2*l3)))
    theta2=math.degrees(math.atan((z-l1)*(math.cos(theta1*math.pi/180)-math.sin(theta1*math.pi/180))/(x-y))) - math.degrees(math.atan((l3*math.sin(theta3*math.pi/180))/(l2 + l3*math.cos(theta3*math.pi/180))))
    
    oa1=oldtheta1 - htheta1 #base
    oa2=oldtheta2 - htheta2 #link 1
    oa3=oldtheta3 - htheta3 #link 2
    
    na1=theta1 - htheta1 #base
    na2=theta2 - htheta2 #link 1
    na3=theta3 - htheta3 #link 2
    
    a1 = na1 - oa1
    a2 = na2 - oa2
    a3 = na3 - oa3
    
    print("\n")
    print("theta1 "+str(theta1)+" theta2:"+str(theta2)+ " theta3:"+str(theta3))
    print("\n")
    print("a1 "+str(a1)+" a2:"+str(a2)+ " a3:"+str(a3))
    print("\n")
    
    ## Gear Ratios
    g1=12.22222222222
    g2=10
    g3=10
     
    step1=(ppr/360)*a1*g1  
    
    step2=(ppr/360)*a2*g2
    
    step3=(ppr/360)*a3*g3  
    
    print(step1)
    print(step2)
    print(step3)
    
    execTime= NFS
    
    if (step1 == 0):
        td1 = 0
    else :
        td1 = execTime/step1
    
    if (step2 == 0):
        td2 = 0
    else:
        td2 = execTime/step2
    
    if (step3 == 0) :
        td3 = 0
    else:
        td3 = execTime/step3
    
    print(td1)
    print(td2)
    print(td3)

    if step1<0:
        dir1="r"
    else:
        dir1="l"

    if step2<0:
        dir2="r"
    else:
        dir2="l"
    
    if step3<0:
        dir3="r"
    else:
        dir3="l"
    
    _thread.start_new_thread( print_time, ("stepper-1", 0.2, s1,abs(step1),dir1,td1))
    _thread.start_new_thread( print_time, ("stepper-2", 0.2, s2,abs(step2),dir2,td2))
    _thread.start_new_thread( print_time, ("stepper-3", 0.2, s3,abs(step3),dir3,td3))
    
    #time.sleep(10)
    


############################# Homing Code ###################

def Homecoming():   
    GPIO.output(DIR, CCW)
    GPIO.output(DIR01, CCW)
    GPIO.output(DIR02, CW)

    GPIO.setup(14, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(15, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    delay = 0.0025

    while(GPIO.input(14) != 0):
        #print (GPIO.input(14))
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
    print (GPIO.input(14))

    while(GPIO.input(15) != 0):
        #print (GPIO.input(15))
        GPIO.output(STEP02, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP02, GPIO.LOW)
        sleep(delay)
    print (GPIO.input(15))

    while(GPIO.input(18) != 0):
        #print (GPIO.input(18))
        GPIO.output(STEP01, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP01, GPIO.LOW)
        sleep(delay)
    print (GPIO.input(18))



