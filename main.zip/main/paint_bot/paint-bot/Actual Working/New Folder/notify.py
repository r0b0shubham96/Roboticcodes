import pyinotify
import ast
#import Read_RAC
#import Read_XY
#import MapCode
#from subprocess import Popen
#import Test_MAPaint#RAPaintMainCode1
import test_kindof_final

global sd
sd=0
def stopitera():
    sd=1

class MyEventHandler(pyinotify.ProcessEvent):
    #def process_IN_ACCESS(self, event):
        #print ("ACCESS event:", event.pathname)

    #def process_IN_ATTRIB(self, event):
        #print ("ATTRIB event:", event.pathname)

    #def process_IN_CLOSE_NOWRITE(self, event):
        #print ("CLOSE_NOWRITE event:", event.pathname)

    def process_IN_CLOSE_WRITE(self, event):
        if (event.pathname=='/home/pi/Downloads/pai/z_output.txt'):
            print("hola")
            with open("/home/pi/Downloads/pai/iteration.txt") as file:
                li=ast.literal_eval(file.read())
##            MAPaint.StartUP()
            
            #c=li[0]
            print("li[0] = ",li[0])
            for i in range(int(li[0])):
                print("############################################################################################################")
                print(i)
                with open("/home/pi/Downloads/pai/some.txt") as file:
                    so=ast.literal_eval(file.read())
                if str(so)=='1':
                    fil=open("some.txt","w")
                    fil.write(str(0))
                    fil.close()
                    break
                    #Test_MAPaint.MainCode()
                    #else:
                        #test_kindof_final.MainCode()
        print ("CLOSE_WRITE event:", event.pathname)

    #def process_IN_CREATE(self, event):
        #print ("CREATE event:", event.pathname)

    #def process_IN_DELETE(self, event):
        #print ("DELETE event:", event.pathname)
    def process_IN_MODIFY(self, event):
        '''
        global firstRun
        if (event.pathname=='/home/pi/Downloads/pai/z_output.txt'):
            if firstRun:
                firstRun = False
                print("hola")
                with open("/home/pi/Downloads/pai/iteration.txt") as file:
                    li=ast.literal_eval(file.read())
##            MAPaint.StartUP()
            
            #c=li[0]
                print("li[0] = ",li[0])
                for i in range(int(li[0])):
                    print("############################################################################################################")
                    print(i)
                    with open("/home/pi/Downloads/pai/some.txt") as file:
                        so=ast.literal_eval(file.read())
                    if str(so)=='1':
                        fil=open("some.txt","w")
                        fil.write(str(0))
                        fil.close()
                        break
                    #Test_MAPaint.MainCode()
                    #else:
                        #test_kindof_final.MainCode()
            else:
                firstRun = True

                with open("/home/pi/Downloads/pai/iteration.txt") as file:
                    li=ast.literal_eval(file.read())
                for i in range(int(li[0])):
                    print("############################################################################################################")
                    print(i)
                '''
                    #Test_MAPaint.MainCode()
                    #test_kindof_final.MainCode()
                #Test_MAPaint.MainCode()           
        print ("MODIFY event:", event.pathname)
        

    #def process_IN_OPEN(self, event):
        #print ("OPEN event:", event.pathname)

firstRun = True 
wm = pyinotify.WatchManager()
wm.add_watch('/home/pi/Downloads/pai', pyinotify.ALL_EVENTS, rec=True)

    # event handler
eh = MyEventHandler()

    # notifier
notifier = pyinotify.Notifier(wm, eh)
notifier.loop()