'''
Code for PaintBot with UI Interface.
'''
#Libraries required for running the Code ///
import math
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep
from Stepper import stepper
import ast
import pyinotify
#/// Home Position of the Bot.
hx = 18.3
hy = 0
hz = 23

global hoi

#[stepPin, directionPin, enablePin]
s1=[6,13,4]    #31,33,7--Rpi pins
s3=[17,27,22]  #11,13,15
s2=[20,21,11]   #38,40,23

######### Link Lenghts in cm for the 
l1=0 
l2=42
l3=34.2

hd = 18.3
vd = 23
horiz_dist = 0
vertc_dist = 0

sideMov00 = 0
sideMov01 = 0

DIR = 13   # Direction GPIO Pin
STEP = 6  # Step GPIO Pin

DIR01 = 27   # Direction GPIO Pin
STEP01 = 17  # Step GPIO Pin

DIR02 = 21   # Direction GPIO Pin
STEP02= 20  # Step GPIO Pin
global pv

NFS = 2
delay = 2

CW = 1     # Clockwise Rotation
CCW = 0    # Counterclockwise Rotation
SPR = 1600   # Steps per Revolution (360 / 7.5)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)
GPIO.setup(5, GPIO.OUT)

################## MAIN CODE #########################################################################################################
def MainCode():
    time.sleep(1)
    with open("/home/pi/Downloads/pai/y_output.txt") as file:
        y_out=ast.literal_eval(file.read())
    print(y_out)    
    with open("/home/pi/Downloads/pai/z_output.txt") as file:
        z_out=ast.literal_eval(file.read())
    print(z_out)
    
    with open("/home/pi/Downloads/pai/iteration.txt") as file:
        li=ast.literal_eval(file.read())
    ################### Input Data ##################
    size = len(y_out)
    print(size)
    ##################### Variables ##################
    sign = 0
    
    NFS = 2 #int(li[1]) 
    delay =  2.5 #int(li[1]) + 0.5 
    
    hd = 18.3
    vd = 23
    horiz_dist = 40
    vertc_dist = y_out[0]

    sideMov00 = 0
    sideMov01 = z_out[0]
    pv=0
    moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist, pv, 4, 4.25)
##    time.sleep(delay)
    
    print(y_out[0])
    print(z_out[0])
    j=0
    
    for i in range((size-1)):
##        NFS = int(li[1]) 
##        delay =  int(li[1]) + 0.5
        pv=1
        GPIO.setwarnings(False)
        #GPIO.output(4,GPIO.HIGH)
        #GPIO.output(5,GPIO.HIGH)
        hd = 40
        vd = y_out[i]
        horiz_dist = 40
        vertc_dist = y_out[i+1]
        hoi=z_out[i+1]
        sideMov00 = z_out[i]
        sideMov01 = z_out[i+1]
        
        y_diff = z_out[i+1] - z_out[i]
        if y_diff > 0:
            y_inc = 0.25
        elif y_diff < 0:
            y_inc = -0.25
        
        y_itr = y_diff/y_inc
        z_diff = y_out[i+1] - y_out[i]
        
        if y_itr != 0:
            z_inc = z_diff/y_itr
            
                
            
            sideMov00 = 0
            sideMov01 = 0
            
            vd = 0
            vertc_dist = 0
            
            for itr in range(int(y_itr)):
                sideMov01 = sideMov00  + y_inc
    ##            sideMov01 = z_out[i] + y_inc*(itr+1)
                
                vd = y_out[i] + z_inc*itr
                vertc_dist = y_out[i] + z_inc*(itr+1)
                
                nfs = 0.15
                delay = 0.15
                
                moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist, pv, nfs, delay)
                sideMov00 = sideMov01
        else:
            sideMov00 = 0
            sideMov01 = 0
            nfs = 2
            delay = 2.25
            moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist, pv, nfs, delay)
        
##        moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist, pv)
        time.sleep(0.25)
        #print("MAIN CODE")
        with open("/home/pi/Downloads/pai/home.txt") as file:
                    ho=ast.literal_eval(file.read())
        if str(ho)=='1':
            if z_out[i+1] < 0 :
                sign = 1
            else:
                sign = 0
            #GPIO.setwarnings(False)
            GPIO.output(4,GPIO.LOW)
            GPIO.output(5,GPIO.LOW)
            Homecoming(sign)
            time.sleep(0.5)
            #GPIO.setwarnings(False)
            GPIO.output(4,GPIO.LOW)
            GPIO.output(5,GPIO.LOW)
            Homecoming(sign)
            time.sleep(2)
            print('Ho')
            j=1
            open("home.txt","w").close()
            fil=open("home.txt","w")
            fil.write(str(0))
            fil.close()
            print('fd')
            fil1=open("some.txt","w")
            fil1.write(str(1))
            fil1.close()
            break
    
    # End of FOR LOOP
    pv=0
    if j==0:
        if z_out[size-1] < 0 :
            sign = 1
        else:
            sign = 0    
        GPIO.output(4,GPIO.LOW)
        GPIO.output(5,GPIO.LOW)
        print(sign)
        Homecoming(sign)
        time.sleep(0.5)
        GPIO.output(4,GPIO.LOW)
        GPIO.output(5,GPIO.LOW)
        Homecoming(sign)
        time.sleep(2)
        
        print('Yo')
########################################################################################################################
    
    '''
    # Code for Homing ... In case it's not working with proximity sensors.
    
    hd = 40
    vd = y_out[size-1]
    horiz_dist = 18.3
    vertc_dist = 23
    sideMov00 = z_out[size-1]
    sideMov01 = 0   

    moveSand(hd, sideMov00, vd, horiz_dist, sideMov01, vertc_dist)
    time.sleep(delay)
    '''
    

########################################################################################################################################
def print_time(threadName, delay, s, steps, dir, speed, pv):
    
    #print("print_time")
    count = 1
    while count >=1:
        time.sleep(delay)
        count -= 1
        #print ("%s: %s" % ( threadName, time.ctime(time.time())))
        testStepper = stepper(s)
        testStepper.step(steps, dir,speed,pv);
        GPIO.output(4,GPIO.HIGH)
        GPIO.output(5,GPIO.HIGH)
      

##########################################################################################################################################################################################


def moveSand(ox, oy, oz, x, y, z, pv, nfs1, delay1):
    ppr=1600  # Pulse Per Revolution
    
    with open("/home/pi/Downloads/pai/iteration.txt") as file:
        li=ast.literal_eval(file.read())
    
##    NFS = int(li[1]) - 0.25
##    delay =  int(li[1])
        
    NFS = nfs1
    delay = delay1
    
    htheta1=math.degrees(math.atan(hy/hx))
    oldtheta1=math.degrees(math.atan(oy/ox))
    theta1=math.degrees(math.atan(y/x))
    
    htheta3=-math.degrees(math.acos((hx*hx+hy*hy+hz*hz-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(hz-l1))/(2*l2*l3)))
    oldtheta3=-math.degrees(math.acos((ox*ox+oy*oy+oz*oz-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(oz-l1))/ (2*l2*l3)))
    theta3=-math.degrees(math.acos((x*x+y*y+z*z-(l1*l1)-(l2*l2)-(l3*l3)-2*l1*(z-l1))/ (2*l2*l3)))
    
    htheta2=math.degrees(math.atan((hz-l1)*(math.cos(htheta1*math.pi/180)-math.sin(htheta1*math.pi/180))/(hx-hy))) - math.degrees(math.atan((l3*math.sin(htheta3*math.pi/180))/(l2 + l3*math.cos(htheta3*math.pi/180))))
    oldtheta2=math.degrees(math.atan((oz-l1)*(math.cos(oldtheta1*math.pi/180)-math.sin(oldtheta1*math.pi/180))/(ox-oy))) - math.degrees(math.atan((l3*math.sin(oldtheta3*math.pi/180))/(l2 + l3*math.cos(oldtheta3*math.pi/180))))
    theta2=math.degrees(math.atan((z-l1)*(math.cos(theta1*math.pi/180)-math.sin(theta1*math.pi/180))/(x-y))) - math.degrees(math.atan((l3*math.sin(theta3*math.pi/180))/(l2 + l3*math.cos(theta3*math.pi/180))))
    
    print("\n")
    print(" ht1: {} ht2: {} ht3: {}".format(round(htheta1,2),round(htheta2,2),round(htheta3,2)))
    print(" ot1: {} ot2: {} ot3: {}".format(round(oldtheta1,2),round(oldtheta2,2),round(oldtheta3,2)))
    print("  x: {} y: {} z: {}".format(round(x,2),round(y,2),round(z,2)))  
        
    oa1=oldtheta1 - htheta1 #base
    oa2=oldtheta2 - htheta2 #link 1
    oa3=oldtheta3 - htheta3 #link 2
    
    na1=theta1 - htheta1 #base
    na2=theta2 - htheta2 #link 1
    na3=theta3 - htheta3 #link 2
    
    a1 = na1 - oa1
    a2 = na2 - oa2
    a3 = na3 - oa3
    
    print(" t1: {} t2: {} t3: {}".format(round(theta1,2),round(theta2,2),round(theta3,2)))
    print(" a1: {} a2: {} a3: {}".format(round(a1,2),round(a2,2),round(a3,2)))
    print("\n")
    
    ## Gear Ratios
    g1=12.22222222222
    g2=10
    g3=10
     
    step1=(ppr/360)*a1*g1  
    step2=(ppr/360)*a2*g2
    step3=(ppr/360)*a3*g3  
    
##    print(step1)
##    print(step2)
##    print(step3)
    
    execTime= NFS
    
    if (step1 == 0):
        td1 = 0
    else :
        td1 = execTime/step1
    
    if (step2 == 0):
        td2 = 0
    else:
        td2 = execTime/step2
    
    if (step3 == 0) :
        td3 = 0
    else:
        td3 = execTime/step3
    
##    print(td1)
##    print(td2)
##    print(td3)

    if step1<0:
        dir1="r"
    else:
        dir1="l"

    if step2<0:
        dir2="r"
    else:
        dir2="l"
    
    if step3<0:
        dir3="r"
    else:
        dir3="l"
    
    _thread.start_new_thread( print_time, ("stepper-1", 0.2, s1,abs(step1),dir1,td1,pv))
    _thread.start_new_thread( print_time, ("stepper-2", 0.2, s2,abs(step2),dir2,td2,pv))
    _thread.start_new_thread( print_time, ("stepper-3", 0.2, s3,abs(step3),dir3,td3,pv))
    
    time.sleep(delay)
    
    '''
    ui=0
    with open("/home/pi/Downloads/pai/pause.txt") as file:
        pa=ast.literal_eval(file.read())
    while str(pa)=='0':
        print(" While ... PAUSE ...")
        GPIO.output(4,GPIO.LOW)
        GPIO.output(5,GPIO.LOW)
        with open("/home/pi/Downloads/pai/pause.txt") as file:
            pa=ast.literal_eval(file.read())
        with open("/home/pi/Downloads/pai/home.txt") as file:
                    ho=ast.literal_eval(file.read())
        if str(ho)=='1':
            if y < 0 :
                sign = 1
            else:
                sign = 0
            Homecoming(sign)
            time.sleep(0.5)
            Homecoming(sign)
            time.sleep(2)
            #print('Ho')
            pa='1'
            ui=1
        
        if str(pa)=='1':
            GPIO.output(4,GPIO.HIGH)
            GPIO.output(5,GPIO.HIGH)
            print("... Resume ... ")
            break
            
            
    if ui == 0:
        #print("MOVESAND")
        _thread.start_new_thread( print_time, ("stepper-1", 0.2, s1,abs(step1),dir1,td1,pv))
        _thread.start_new_thread( print_time, ("stepper-2", 0.2, s2,abs(step2),dir2,td2,pv))
        _thread.start_new_thread( print_time, ("stepper-3", 0.2, s3,abs(step3),dir3,td3,pv))
        #print("movesand fin")
    #time.sleep(10)
    '''


############################# Homing Code ###################

def Homecoming(direct):   
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    
    GPIO.setup(DIR, GPIO.OUT)
    GPIO.setup(STEP, GPIO.OUT)

    GPIO.setup(DIR01, GPIO.OUT)
    GPIO.setup(STEP01, GPIO.OUT)

    GPIO.setup(DIR02, GPIO.OUT)
    GPIO.setup(STEP02, GPIO.OUT)
    
    GPIO.output(4,GPIO.LOW)
    GPIO.output(5,GPIO.LOW)
    
    print('*************************************************************************************************')
    print(direct)
    
    if direct == 0 :
        GPIO.output(DIR, CCW)
        print(" Counter Clockwise")
    elif direct == 1:
        GPIO.output(DIR, CW)
        print(" Clockwise")
    
    GPIO.output(DIR01, CCW)
    GPIO.output(DIR02, CW)

    GPIO.setup(25, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(8, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    
    delay = 0.0008

    time.sleep(1)
    
    while(GPIO.input(25) != 0 or GPIO.input(8) != 0 or GPIO.input(7) !=0):
        if GPIO.input(25)!=0:
            GPIO.output(STEP, GPIO.HIGH)
            sleep(delay)
            GPIO.output(STEP, GPIO.LOW)
            sleep(delay)
        if GPIO.input(8)!=0:
            GPIO.output(STEP02, GPIO.HIGH)
            sleep(delay)
            GPIO.output(STEP02, GPIO.LOW)
            sleep(delay)
        if GPIO.input(7)!=0:
            GPIO.output(STEP01, GPIO.HIGH)
            sleep(delay)
            GPIO.output(STEP01, GPIO.LOW)
            sleep(delay)
    print (GPIO.input(25))
    print (GPIO.input(8))
    print (GPIO.input(7))

