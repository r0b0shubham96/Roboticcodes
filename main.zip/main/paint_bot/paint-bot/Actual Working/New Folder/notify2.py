import pyinotify
import ast
import go

class MyEventHandler(pyinotify.ProcessEvent):

    def process_IN_CLOSE_WRITE(self, event):
        if (event.pathname=='/home/pi/Downloads/pai/z_output.txt'):
            print("hola")
            with open("/home/pi/Downloads/pai/iteration.txt") as file:
                li=ast.literal_eval(file.read())
            print("li[0] = ",li[0])
            for i in range(int(li[0])):
                print("############################################################################################################")
                print(i)
                with open("/home/pi/Downloads/pai/some.txt") as file:
                    so=ast.literal_eval(file.read())
                if str(so)=='1':
                    fil=open("some.txt","w")
                    fil.write(str(0))
                    fil.close()
                    break
                else:
                    go.MainCode()
        print ("CLOSE_WRITE event:", event.pathname)
        
    def process_IN_MODIFY(self, event):
        print ("MODIFY event:", event.pathname)

firstRun = True 
wm = pyinotify.WatchManager()
wm.add_watch('/home/pi/Downloads/pai', pyinotify.ALL_EVENTS, rec=True)

    # event handler
eh = MyEventHandler()

    # notifier
notifier = pyinotify.Notifier(wm, eh)
notifier.loop()

