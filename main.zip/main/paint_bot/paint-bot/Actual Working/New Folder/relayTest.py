import math
import _thread
import time
import RPi.GPIO as GPIO
from time import sleep

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)
GPIO.setup(5, GPIO.OUT)
##GPIO.output(4,GPIO.HIGH)
##GPIO.output(5,GPIO.HIGH)

while True:
    #GPIO.output(4,GPIO.HIGH)
    #GPIO.output(5,GPIO.HIGH)
    #time.sleep(2)
    GPIO.output(4,GPIO.LOW)
    GPIO.output(5,GPIO.LOW)
    time.sleep(4)