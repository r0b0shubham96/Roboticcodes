# RoboticArm
This contains the code for running the stepper motors for the Robotic Arm-Optimus 2
